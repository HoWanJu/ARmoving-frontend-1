package com.movehome.armoving

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageButton

class MeasuringActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_measuring)

        val button = findViewById<ImageButton>(R.id.measure_done)
        button.setOnClickListener {
            val intent = Intent(this, FurnitureActivity::class.java)
            startActivity(intent)
        }
    }
}