package com.movehome.armoving

class FurnitureModel (val title: String, val des: String, val image: Int) {
}